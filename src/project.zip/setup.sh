#!/bin/bash

# Script de configuration du projet Skylanders Universe
# Usage: bash setup.sh

echo "🎮 Configuration de Skylanders Universe..."
echo ""

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé. Installez-le depuis https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node -v) détecté"
echo ""

# Vérifier npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm n'est pas installé"
    exit 1
fi

echo "✅ npm $(npm -v) détecté"
echo ""

# Installer les dépendances
echo "📦 Installation des dépendances..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Dépendances installées avec succès"
else
    echo "❌ Erreur lors de l'installation des dépendances"
    exit 1
fi

echo ""

# Créer .env.local si n'existe pas
if [ ! -f .env.local ]; then
    echo "📝 Création du fichier .env.local..."
    cp .env.example .env.local
    echo "⚠️  N'oubliez pas de remplir .env.local avec vos clés Supabase !"
else
    echo "✅ .env.local existe déjà"
fi

echo ""
echo "🎉 Configuration terminée !"
echo ""
echo "Prochaines étapes :"
echo "1. Éditez .env.local avec vos clés Supabase"
echo "2. Lancez le serveur de dev : npm run dev"
echo "3. Ouvrez http://localhost:3000"
echo ""
echo "📚 Documentation complète : README.md"
echo "🚀 Guide rapide : QUICK_START.md"
echo ""
