# 🏗️ Architecture du projet Skylanders Universe

Ce document décrit l'architecture technique du projet.

## 📊 Vue d'ensemble

```
┌─────────────────────────────────────────────────────┐
│                   Utilisateur                        │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│              Application React (SPA)                 │
│  ┌──────────────────────────────────────────────┐  │
│  │           Routing (Client-side)              │  │
│  │  Home | Skylanders | Games | Guides | ...   │  │
│  └──────────────────────────────────────────────┘  │
│                                                      │
│  ┌──────────────┐  ┌──────────────┐               │
│  │  AuthContext │  │ ThemeContext │  Contexts     │
│  └──────────────┘  └──────────────┘               │
│                                                      │
│  ┌──────────────────────────────────────────────┐  │
│  │         Composants UI (Radix + Custom)       │  │
│  │  Cards | Buttons | Forms | Modals | ...     │  │
│  └──────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│               Supabase (Backend)                     │
│  ┌──────────────┐  ┌──────────────┐               │
│  │     Auth     │  │   Database   │  Services     │
│  │ (OAuth, JWT) │  │ (PostgreSQL) │               │
│  └──────────────┘  └──────────────┘               │
│                                                      │
│  ┌──────────────────────────────────────────────┐  │
│  │          Storage (Images, Files)             │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

## 🗂️ Structure des dossiers

### `/components` - Composants React

```
components/
├── auth/                   # Authentification
│   ├── AuthModal.tsx      # Modal de connexion/inscription
│   ├── AccountDrawer.tsx  # Menu utilisateur
│   └── ...
├── ui/                    # Composants UI de base (Radix + custom)
│   ├── button.tsx
│   ├── card.tsx
│   ├── dialog.tsx
│   └── ...
├── figma/                 # Helpers pour les assets
│   └── ImageWithFallback.tsx
├── Header.tsx             # En-tête principal
├── Footer.tsx             # Pied de page
├── SkylanderCard.tsx      # Carte Skylander
├── GameCard.tsx           # Carte de jeu
└── ...
```

**Principe :** Composants réutilisables, chacun avec une responsabilité unique.

### `/pages` - Pages de l'application

```
pages/
├── Home.tsx               # Page d'accueil
├── SkylandersList.tsx     # Liste des Skylanders
├── SkylanderDetail.tsx    # Détail d'un Skylander
├── Games.tsx              # Liste des jeux
├── GameDetail.tsx         # Détail d'un jeu
├── Guides.tsx             # Liste des guides
├── GuideDetail.tsx        # Lecture d'un guide
├── GuideEditor.tsx        # Création/édition de guide
├── Profile.tsx            # Profil utilisateur
├── Collections.tsx        # Collections utilisateur
├── Admin.tsx              # Interface admin
└── ...
```

**Principe :** Une page = une route/vue principale de l'application.

### `/contexts` - Contextes React

```
contexts/
├── AuthContext.tsx        # Gestion de l'authentification
│   - user, session
│   - signIn, signUp, signOut
│   - isAdmin
└── ThemeContext.tsx       # Gestion du thème
    - theme (light/dark)
    - setTheme
```

**Principe :** État global partagé entre composants.

### `/data` - Données statiques

```
data/
├── skylanders.ts          # Base de données complète
│   - Liste de 350+ Skylanders
│   - Informations sur les jeux
│   - Types et interfaces
└── images-config.ts       # Configuration des images
```

**Principe :** Données en lecture seule, pas de logique.

### `/utils` - Fonctions utilitaires

```
utils/
├── supabase/
│   ├── client.ts          # Client Supabase initialisé
│   └── info.ts            # Configuration Supabase
├── api.ts                 # Helper pour les appels API
└── collection.ts          # Gestion des collections locales
```

**Principe :** Fonctions pures et réutilisables.

### `/config` - Configuration

```
config/
├── site.config.ts         # Configuration du site
│   - Métadonnées
│   - Navigation
│   - Constantes
└── paths.config.ts        # Chemins et routes
```

### `/styles` - Styles globaux

```
styles/
└── globals.css            # Styles Tailwind + custom
    - Variables CSS
    - Thème (dark/light)
    - Classes utilitaires
```

## 🔄 Flux de données

### Authentification

```
User Action (Login)
    ↓
AuthModal Component
    ↓
AuthContext.signIn()
    ↓
Supabase Auth API
    ↓
onAuthStateChange listener
    ↓
Update AuthContext state
    ↓
Re-render components using useAuth()
```

### Chargement de données

```
Page Component (useEffect)
    ↓
API Call (utils/api.ts)
    ↓
Supabase Database
    ↓
Response Data
    ↓
setState in Component
    ↓
Render UI
```

### Gestion de collections (local)

```
User Action (Add to Wishlist)
    ↓
Component Event Handler
    ↓
updateCollection() (utils/collection.ts)
    ↓
localStorage.setItem()
    ↓
Update Component State
    ↓
Re-render
```

## 🎨 Stack technique

### Frontend

| Technologie | Rôle | Version |
|------------|------|---------|
| **React** | Framework UI | 18.3.1 |
| **TypeScript** | Typage statique | 5.7.2 |
| **Vite** | Build tool | 6.0.5 |
| **Tailwind CSS** | Styles | 4.0.0 |
| **Framer Motion** | Animations | 11.14.4 |
| **Radix UI** | Composants accessibles | 1.x |
| **Lucide React** | Icônes | 0.462.0 |

### Backend (Supabase)

| Service | Utilisation |
|---------|-------------|
| **Authentication** | Gestion des utilisateurs (email, OAuth) |
| **Database** | PostgreSQL pour guides, profils |
| **Storage** | Stockage d'images (optionnel) |
| **Real-time** | Mises à jour live (futur) |

## 🔐 Sécurité

### Authentification

- **JWT Tokens** pour les sessions
- **OAuth 2.0** pour Google/GitHub/Discord
- **Email verification** obligatoire
- **Row Level Security (RLS)** dans Supabase

### Variables d'environnement

```env
# Public (incluses dans le build)
VITE_SUPABASE_URL           # URL du projet Supabase
VITE_SUPABASE_ANON_KEY      # Clé publique (safe)

# Privées (backend uniquement)
SUPABASE_SERVICE_ROLE_KEY   # Clé service (JAMAIS exposée)
```

### Validation

- **TypeScript** pour le typage fort
- **Zod** pour la validation runtime (à ajouter)
- **Sanitization** des inputs utilisateur

## 📱 Responsive Design

### Breakpoints (Tailwind)

```css
/* Mobile first */
/* Default: < 640px */

sm: 640px    /* Tablette portrait */
md: 768px    /* Tablette landscape */
lg: 1024px   /* Desktop petit */
xl: 1280px   /* Desktop */
2xl: 1536px  /* Desktop large */
```

### Stratégie

1. **Mobile first** : Design pour mobile d'abord
2. **Progressive enhancement** : Ajouter fonctionnalités pour grand écran
3. **Touch-friendly** : Boutons >= 44px
4. **Lazy loading** : Images chargées à la demande

## ⚡ Performance

### Optimisations

1. **Code splitting**
   - Routes lazy-loadées
   - Chunks par vendor (React, Radix, etc.)

2. **Images**
   - Lazy loading natif
   - Format WebP/AVIF
   - Placeholders pendant le chargement

3. **Cache**
   - Service Worker (à implémenter)
   - localStorage pour collections
   - Cache-Control headers

4. **Bundle**
   - Tree shaking automatique
   - Minification CSS/JS
   - Gzip/Brotli compression

### Métriques cibles

| Métrique | Cible |
|----------|-------|
| First Contentful Paint | < 1.5s |
| Largest Contentful Paint | < 2.5s |
| Time to Interactive | < 3.5s |
| Cumulative Layout Shift | < 0.1 |

## 🧪 Tests (à implémenter)

```
tests/
├── unit/              # Tests unitaires
│   ├── utils/
│   └── components/
├── integration/       # Tests d'intégration
│   └── flows/
└── e2e/              # Tests end-to-end
    └── scenarios/
```

**Stack recommandée :**
- Vitest (unit tests)
- React Testing Library
- Playwright (E2E)

## 🚀 CI/CD

### GitHub Actions

```yaml
Build → Test → Deploy
  ↓      ↓       ↓
 Vite  Vitest  Vercel/Netlify
```

### Workflow

1. **Push sur main**
2. **GitHub Actions se déclenche**
3. **Install dependencies**
4. **Run linter**
5. **Run tests** (si présents)
6. **Build app**
7. **Deploy to Vercel/Netlify**

## 📊 Monitoring (à implémenter)

### Outils recommandés

- **Sentry** : Erreurs et crashes
- **Google Analytics** : Analytics
- **Vercel Analytics** : Web Vitals
- **LogRocket** : Session replay

## 🔮 Évolutions futures

### Court terme
- [ ] Tests unitaires
- [ ] Service Worker (PWA)
- [ ] SEO optimization
- [ ] Open Graph tags

### Moyen terme
- [ ] API publique
- [ ] Webhooks
- [ ] Système de badges
- [ ] Mode hors-ligne

### Long terme
- [ ] Application mobile (React Native)
- [ ] Desktop app (Electron)
- [ ] Marketplace
- [ ] ML pour recommandations

---

**Documentation maintenue par l'équipe Skylanders Universe**
