# 🎮 Skylanders Universe

Une application web complète dédiée à l'univers Skylanders avec base de données interactive, guides communautaires, système d'authentification et gestion de collections personnalisées.

![Skylanders Universe](https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&h=400&fit=crop)

## ✨ Fonctionnalités

### 🎯 Base de données complète
- **350+ personnages Skylanders** avec informations détaillées
- Filtrage avancé par élément, famille, jeu et série
- Recherche en temps réel
- Fiches détaillées avec images, stats et descriptions

### 📚 Système de guides communautaires
- Création de guides (walkthroughs, astuces, glitchs)
- Éditeur Markdown intégré avec prévisualisation
- Système de votes et commentaires
- Filtrage par jeu, type et difficulté
- Interface d'administration pour les modérateurs

### 👤 Authentification & Profils
- Connexion par email/mot de passe avec vérification
- Authentification OAuth (Google, GitHub, Discord)
- Profils personnalisables
- Gestion des préférences (thème, notifications, confidentialité)

### 📦 Collections personnelles
- Liste de souhaits (wishlist)
- Collection de Skylanders possédés
- Statistiques de complétion par élément
- Progression globale

### 🎨 Interface moderne
- Design responsive (mobile, tablette, desktop)
- Mode sombre/clair
- Animations fluides avec Framer Motion
- Effets glass-morphism
- Composants UI accessibles (Radix UI)

## 🚀 Installation locale

### Prérequis

- **Node.js** 18+ ([télécharger](https://nodejs.org/))
- **npm** ou **yarn** ou **pnpm**
- Un compte **Supabase** (gratuit) pour l'authentification ([créer un compte](https://supabase.com))

### Étapes d'installation

1. **Cloner le repository**
```bash
git clone https://github.com/votre-username/skylanders-universe.git
cd skylanders-universe
```

2. **Installer les dépendances**
```bash
npm install
# ou
yarn install
# ou
pnpm install
```

3. **Configuration Supabase**

Créez un fichier `.env.local` à la racine du projet :

```env
VITE_SUPABASE_URL=https://votre-projet.supabase.co
VITE_SUPABASE_ANON_KEY=votre-cle-publique-ici
VITE_SUPABASE_PROJECT_ID=votre-projet-id
```

Pour obtenir vos identifiants Supabase :
- Connectez-vous à [Supabase](https://supabase.com)
- Créez un nouveau projet
- Allez dans **Settings** > **API**
- Copiez l'URL et la clé `anon` (publique)

4. **Configurer l'authentification Google (optionnel)**

Dans votre projet Supabase :
- Allez dans **Authentication** > **Providers**
- Activez Google
- Configurez les identifiants OAuth depuis [Google Cloud Console](https://console.cloud.google.com)

5. **Lancer le serveur de développement**
```bash
npm run dev
```

L'application sera accessible sur `http://localhost:3000`

## 📦 Build de production

```bash
npm run build
```

Le dossier `dist/` contiendra les fichiers optimisés pour la production.

### Prévisualiser le build

```bash
npm run preview
```

## 🌐 Déploiement

### Déploiement sur Vercel (recommandé)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/votre-username/skylanders-universe)

**Étapes manuelles :**

1. Créez un compte sur [Vercel](https://vercel.com)

2. Installez Vercel CLI (optionnel)
```bash
npm i -g vercel
```

3. Déployez
```bash
vercel
```

4. Configurez les variables d'environnement dans Vercel :
   - Allez dans **Settings** > **Environment Variables**
   - Ajoutez `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`

### Déploiement sur Netlify

1. Créez un compte sur [Netlify](https://netlify.com)

2. Connectez votre repository GitHub

3. Configurez le build :
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`

4. Ajoutez les variables d'environnement dans **Site settings** > **Environment variables**

### Déploiement sur GitHub Pages

1. Modifiez `vite.config.ts` :
```ts
export default defineConfig({
  base: '/skylanders-universe/', // nom de votre repo
  // ...
});
```

2. Ajoutez un workflow GitHub Actions (`.github/workflows/deploy.yml`) :
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        env:
          VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}
        
      - name: Deploy
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

3. Ajoutez les secrets dans **Settings** > **Secrets and variables** > **Actions**

## 🏗️ Structure du projet

```
skylanders-universe/
├── components/          # Composants React réutilisables
│   ├── auth/           # Composants d'authentification
│   ├── ui/             # Composants UI (Radix + custom)
│   ├── figma/          # Composants helpers
│   ├── Header.tsx      # En-tête de navigation
│   ├── Footer.tsx      # Pied de page
│   ├── SkylanderCard.tsx
│   ├── GameCard.tsx
│   └── ...
├── pages/              # Pages de l'application
│   ├── Home.tsx
│   ├── SkylandersList.tsx
│   ├── SkylanderDetail.tsx
│   ├── Games.tsx
│   ├── Guides.tsx
│   ├── Profile.tsx
│   ├── Admin.tsx
│   └── ...
├── contexts/           # Contextes React (Auth, Theme)
│   ├── AuthContext.tsx
│   └── ThemeContext.tsx
├── data/               # Données statiques
│   ├── skylanders.ts   # Base de données Skylanders
│   └── images-config.ts
├── utils/              # Fonctions utilitaires
│   ├── supabase/
│   ├── api.ts
│   └── collection.ts
├── styles/             # Styles CSS
│   └── globals.css
├── config/             # Configuration
│   ├── site.config.ts
│   └── paths.config.ts
├── lib/                # Bibliothèques helpers
│   └── utils.ts
├── App.tsx             # Composant racine
├── main.tsx            # Point d'entrée React
├── index.html          # HTML de base
├── vite.config.ts      # Configuration Vite
├── tailwind.config.ts  # Configuration Tailwind
├── tsconfig.json       # Configuration TypeScript
└── package.json        # Dépendances
```

## 🛠️ Technologies utilisées

- **React 18** - Bibliothèque UI
- **TypeScript** - Typage statique
- **Vite** - Build tool ultra-rapide
- **Tailwind CSS** - Framework CSS utilitaire
- **Framer Motion** - Animations
- **Radix UI** - Composants accessibles
- **Supabase** - Backend (Auth, Database)
- **Lucide React** - Icônes
- **React Markdown** - Rendu Markdown

## 📝 Fonctionnalités d'administration

Les utilisateurs avec des droits d'administrateur peuvent :
- Accéder à l'interface d'administration (`/admin`)
- Voir tous les guides (publiés et brouillons)
- Supprimer des guides inappropriés
- Voir les statistiques globales

Pour configurer un admin, modifiez `ADMIN_EMAILS` dans `/contexts/AuthContext.tsx` :
```typescript
const ADMIN_EMAILS = ['votre-email@example.com'];
```

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer :

1. Forkez le projet
2. Créez une branche (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add AmazingFeature'`)
4. Pushez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus d'informations.

## 🎯 Roadmap

- [ ] Mode hors-ligne (PWA)
- [ ] Export de collection en PDF
- [ ] Système de badges et achievements
- [ ] Comparateur de Skylanders
- [ ] API publique
- [ ] Application mobile (React Native)
- [ ] Marketplace communautaire
- [ ] Intégration avec eBay/Amazon pour les prix

## 💬 Support

Pour toute question ou problème :
- Ouvrez une [issue](https://github.com/votre-username/skylanders-universe/issues)
- Contactez-nous par email : support@skylanders-universe.com

## 🙏 Remerciements

- Activision pour l'univers Skylanders
- La communauté Skylanders
- Tous les contributeurs au projet

---

**Fait avec ❤️ par la communauté Skylanders**
