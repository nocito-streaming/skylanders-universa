# 🤝 Guide de contribution

Merci de votre intérêt pour contribuer à Skylanders Universe ! Ce guide vous aidera à commencer.

## 📋 Table des matières

- [Code de conduite](#code-de-conduite)
- [Comment contribuer](#comment-contribuer)
- [Structure du projet](#structure-du-projet)
- [Standards de code](#standards-de-code)
- [Processus de Pull Request](#processus-de-pull-request)

## 📜 Code de conduite

En participant à ce projet, vous acceptez de respecter notre code de conduite :

- Soyez respectueux et inclusif
- Acceptez les critiques constructives
- Concentrez-vous sur ce qui est le mieux pour la communauté
- Faites preuve d'empathie envers les autres membres

## 🚀 Comment contribuer

### Signaler un bug

1. Vérifiez que le bug n'a pas déjà été signalé dans les [Issues](https://github.com/votre-username/skylanders-universe/issues)
2. Créez une nouvelle issue avec le template "Bug Report"
3. Incluez :
   - Description claire du problème
   - Étapes pour reproduire
   - Comportement attendu vs observé
   - Captures d'écran si applicable
   - Environnement (OS, navigateur, version)

### Proposer une fonctionnalité

1. Créez une issue avec le template "Feature Request"
2. Décrivez clairement la fonctionnalité
3. Expliquez pourquoi elle serait utile
4. Proposez une implémentation si possible

### Contribuer au code

1. **Forkez le repository**
```bash
git clone https://github.com/votre-username/skylanders-universe.git
cd skylanders-universe
```

2. **Créez une branche**
```bash
git checkout -b feature/ma-fonctionnalite
# ou
git checkout -b fix/mon-correctif
```

3. **Installez les dépendances**
```bash
npm install
```

4. **Faites vos modifications**
   - Suivez les [standards de code](#standards-de-code)
   - Testez vos changements
   - Ajoutez des tests si nécessaire

5. **Commitez vos changements**
```bash
git add .
git commit -m "feat: ajoute une super fonctionnalité"
```

Utilisez des messages de commit conventionnels :
- `feat:` nouvelle fonctionnalité
- `fix:` correction de bug
- `docs:` documentation
- `style:` formatage, points-virgules manquants, etc.
- `refactor:` refactorisation du code
- `test:` ajout de tests
- `chore:` mise à jour des tâches de build, etc.

6. **Pushez vers votre fork**
```bash
git push origin feature/ma-fonctionnalite
```

7. **Créez une Pull Request**
   - Allez sur GitHub
   - Cliquez sur "New Pull Request"
   - Remplissez le template de PR
   - Attendez la revue

## 📁 Structure du projet

```
skylanders-universe/
├── components/          # Composants React
│   ├── auth/           # Auth (login, register, etc.)
│   ├── ui/             # Composants UI réutilisables
│   ├── SkylanderCard.tsx
│   └── ...
├── pages/              # Pages de l'application
│   ├── Home.tsx
│   ├── SkylandersList.tsx
│   └── ...
├── contexts/           # Contextes React
│   ├── AuthContext.tsx
│   └── ThemeContext.tsx
├── data/               # Données statiques
│   └── skylanders.ts
├── utils/              # Fonctions utilitaires
│   ├── supabase/
│   └── api.ts
├── styles/             # Styles globaux
│   └── globals.css
└── config/             # Configuration
    └── site.config.ts
```

## 🎨 Standards de code

### TypeScript

- Utilisez TypeScript pour tous les nouveaux fichiers
- Typez explicitement les props des composants
- Évitez `any`, préférez `unknown` si nécessaire
- Utilisez des interfaces pour les objets complexes

```typescript
// ✅ Bon
interface SkylanderCardProps {
  skylander: Skylander;
  onCardClick: (id: string) => void;
  isFavorite: boolean;
}

export function SkylanderCard({ skylander, onCardClick, isFavorite }: SkylanderCardProps) {
  // ...
}

// ❌ Mauvais
export function SkylanderCard(props: any) {
  // ...
}
```

### React

- Utilisez des composants fonctionnels avec hooks
- Suivez le principe de responsabilité unique
- Extrayez la logique complexe dans des hooks personnalisés
- Mémoïsez les calculs coûteux avec `useMemo`
- Mémoïsez les callbacks avec `useCallback`

```typescript
// ✅ Bon
export function SkylandersList({ searchQuery }: Props) {
  const filteredSkylanders = useMemo(
    () => skylanders.filter(s => s.name.includes(searchQuery)),
    [searchQuery]
  );

  const handleClick = useCallback((id: string) => {
    // ...
  }, []);

  return (
    <div>
      {filteredSkylanders.map(s => (
        <SkylanderCard key={s.id} skylander={s} onClick={handleClick} />
      ))}
    </div>
  );
}
```

### CSS / Tailwind

- Utilisez Tailwind CSS pour le styling
- Évitez les styles inline
- Utilisez les classes utilitaires de Tailwind
- Respectez le mode sombre avec `dark:`

```tsx
// ✅ Bon
<div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
  <h2 className="text-gray-900 dark:text-white">Titre</h2>
</div>

// ❌ Mauvais
<div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '16px' }}>
  <h2 style={{ color: '#000' }}>Titre</h2>
</div>
```

### Naming

- **Composants:** PascalCase (`SkylanderCard.tsx`)
- **Hooks:** camelCase avec préfixe `use` (`useSkylanders.ts`)
- **Utilitaires:** camelCase (`formatDate.ts`)
- **Constantes:** UPPER_SNAKE_CASE (`MAX_SKYLANDERS`)
- **Types/Interfaces:** PascalCase (`Skylander`, `UserProfile`)

### Imports

Organisez les imports par groupes :

```typescript
// 1. Bibliothèques externes
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

// 2. Composants locaux
import { Button } from '../components/ui/button';
import { SkylanderCard } from '../components/SkylanderCard';

// 3. Utilitaires et contextes
import { useAuth } from '../contexts/AuthContext';
import { formatDate } from '../utils/formatDate';

// 4. Types
import type { Skylander } from '../types';

// 5. Styles (si nécessaire)
import './styles.css';
```

### Commentaires

- Commentez le "pourquoi", pas le "quoi"
- Utilisez JSDoc pour les fonctions utilitaires
- Documentez les props complexes

```typescript
/**
 * Filtre les Skylanders par élément et famille
 * @param skylanders - Liste complète des Skylanders
 * @param element - Élément à filtrer (ou 'all')
 * @param family - Famille à filtrer (ou 'all')
 * @returns Liste filtrée
 */
export function filterSkylanders(
  skylanders: Skylander[],
  element: string,
  family: string
): Skylander[] {
  // ...
}
```

## 🔍 Processus de Pull Request

### Avant de soumettre

- [ ] Le code compile sans erreurs
- [ ] Le code respecte les standards ESLint
- [ ] Les tests existants passent
- [ ] Vous avez testé manuellement vos changements
- [ ] La documentation est à jour si nécessaire
- [ ] Les messages de commit suivent la convention

### Checklist de la PR

Quand vous créez une PR, assurez-vous de :

1. **Donner un titre descriptif**
   - ✅ `feat: ajoute le filtrage par série pour les Skylanders`
   - ❌ `mise à jour`

2. **Remplir la description**
   - Qu'est-ce qui change ?
   - Pourquoi ce changement est nécessaire ?
   - Comment tester ?
   - Screenshots si applicable

3. **Lier les issues**
   - Utilisez `Closes #123` si la PR ferme une issue

4. **Demander une revue**
   - Assignez des reviewers
   - Répondez aux commentaires
   - Faites les modifications demandées

### Processus de revue

1. Un mainteneur examine votre PR
2. Des changements peuvent être demandés
3. Vous effectuez les modifications
4. La PR est approuvée et mergée

## 🎯 Domaines où contribuer

### Facile (bon pour débuter)

- Corriger les fautes de frappe
- Améliorer la documentation
- Ajouter des tests
- Corriger des bugs mineurs

### Moyen

- Ajouter de nouveaux Skylanders à la base de données
- Améliorer l'UI/UX
- Optimiser les performances
- Ajouter des fonctionnalités simples

### Avancé

- Refactoriser du code
- Implémenter de grandes fonctionnalités
- Optimiser l'architecture
- Intégrer de nouvelles APIs

## 🆘 Besoin d'aide ?

N'hésitez pas à :
- Poser des questions dans les [Discussions](https://github.com/votre-username/skylanders-universe/discussions)
- Rejoindre notre Discord (lien à venir)
- Contacter les mainteneurs

## 📚 Ressources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [Conventional Commits](https://www.conventionalcommits.org/)

---

**Merci de contribuer à Skylanders Universe ! 🎮✨**
