# 🚀 Guide de déploiement complet

Ce guide détaille toutes les options de déploiement pour Skylanders Universe.

## 📋 Table des matières

- [Préparation](#préparation)
- [Vercel (Recommandé)](#vercel-recommandé)
- [Netlify](#netlify)
- [GitHub Pages](#github-pages)
- [Cloud Run (Google Cloud)](#cloud-run-google-cloud)
- [Docker](#docker)
- [Serveur VPS](#serveur-vps)

## 🎯 Préparation

Avant de déployer, assurez-vous que :

1. **Le build fonctionne localement**
```bash
npm run build
npm run preview
```

2. **Les variables d'environnement sont prêtes**
```env
VITE_SUPABASE_URL=https://votre-projet.supabase.co
VITE_SUPABASE_ANON_KEY=votre-cle-anon
VITE_SUPABASE_PROJECT_ID=votre-projet-id
```

3. **Le code est sur Git**
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/votre-username/skylanders-universe.git
git push -u origin main
```

## 🎨 Vercel (Recommandé)

Vercel est parfait pour les apps React/Vite avec un déploiement en 1 clic.

### Méthode 1 : Interface web

1. **Créer un compte**
   - Allez sur [vercel.com](https://vercel.com)
   - Connectez-vous avec GitHub

2. **Importer le projet**
   - Cliquez sur "Add New" → "Project"
   - Sélectionnez votre repository GitHub
   - Cliquez sur "Import"

3. **Configurer**
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`

4. **Ajouter les variables d'environnement**
   - Dans "Environment Variables"
   - Ajoutez chaque variable (VITE_SUPABASE_URL, etc.)
   - Cliquez sur "Deploy"

5. **Domaine personnalisé (optionnel)**
   - Settings → Domains
   - Ajoutez votre domaine
   - Configurez les DNS selon les instructions

### Méthode 2 : CLI

```bash
# Installer Vercel CLI
npm i -g vercel

# Se connecter
vercel login

# Déployer
vercel

# Ajouter les variables d'environnement
vercel env add VITE_SUPABASE_URL production
vercel env add VITE_SUPABASE_ANON_KEY production

# Redéployer avec les variables
vercel --prod
```

### Configuration avancée

Créez `vercel.json` :
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ],
  "headers": [
    {
      "source": "/assets/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ]
}
```

## 🌐 Netlify

### Méthode 1 : Interface web

1. **Créer un compte**
   - Allez sur [netlify.com](https://netlify.com)
   - Connectez-vous avec GitHub

2. **Importer le projet**
   - "Add new site" → "Import an existing project"
   - Sélectionnez GitHub et votre repository

3. **Configurer le build**
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
   - **Node version:** 18

4. **Variables d'environnement**
   - Site settings → Environment variables
   - Ajoutez VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY

5. **Déployer**
   - Cliquez sur "Deploy site"

### Méthode 2 : CLI

```bash
# Installer Netlify CLI
npm i -g netlify-cli

# Se connecter
netlify login

# Initialiser
netlify init

# Déployer
netlify deploy --prod
```

### Configuration Netlify

Créez `netlify.toml` :
```toml
[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/assets/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"
```

## 📄 GitHub Pages

### Configuration

1. **Modifier vite.config.ts**
```typescript
export default defineConfig({
  base: '/skylanders-universe/', // Nom de votre repo
  // ... reste de la config
});
```

2. **Créer le workflow GitHub Actions**

Créez `.github/workflows/deploy.yml` :
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build
        run: npm run build
        env:
          VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}

      - name: Setup Pages
        uses: actions/configure-pages@v4

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

3. **Ajouter les secrets**
   - Settings → Secrets and variables → Actions
   - Ajoutez VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY

4. **Activer GitHub Pages**
   - Settings → Pages
   - Source : GitHub Actions

5. **Pushez sur main**
```bash
git add .
git commit -m "Add GitHub Pages deployment"
git push
```

Votre site sera sur : `https://votre-username.github.io/skylanders-universe/`

## ☁️ Cloud Run (Google Cloud)

### Prérequis
- Compte Google Cloud
- gcloud CLI installé

### Déploiement

1. **Créer un Dockerfile**
```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 8080
CMD ["nginx", "-g", "daemon off;"]
```

2. **Créer nginx.conf**
```nginx
server {
    listen 8080;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

3. **Build et déployer**
```bash
# Créer un projet
gcloud projects create skylanders-universe

# Activer Cloud Run
gcloud services enable run.googleapis.com

# Build l'image
gcloud builds submit --tag gcr.io/skylanders-universe/app

# Déployer
gcloud run deploy skylanders-universe \
  --image gcr.io/skylanders-universe/app \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars "VITE_SUPABASE_URL=...,VITE_SUPABASE_ANON_KEY=..."
```

## 🐳 Docker

### Dockerfile de production

```dockerfile
# Build stage
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
ARG VITE_SUPABASE_URL
ARG VITE_SUPABASE_ANON_KEY
ENV VITE_SUPABASE_URL=$VITE_SUPABASE_URL
ENV VITE_SUPABASE_ANON_KEY=$VITE_SUPABASE_ANON_KEY
RUN npm run build

# Production stage
FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      args:
        VITE_SUPABASE_URL: ${VITE_SUPABASE_URL}
        VITE_SUPABASE_ANON_KEY: ${VITE_SUPABASE_ANON_KEY}
    ports:
      - "80:80"
    restart: unless-stopped
```

### Utilisation

```bash
# Build
docker build -t skylanders-universe \
  --build-arg VITE_SUPABASE_URL=... \
  --build-arg VITE_SUPABASE_ANON_KEY=... .

# Run
docker run -p 80:80 skylanders-universe

# Avec docker-compose
docker-compose up -d
```

## 🖥️ Serveur VPS (Ubuntu)

### Installation sur un serveur

```bash
# 1. Se connecter au serveur
ssh user@votre-serveur.com

# 2. Installer Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Installer nginx
sudo apt install nginx

# 4. Cloner le projet
git clone https://github.com/votre-username/skylanders-universe.git
cd skylanders-universe

# 5. Installer les dépendances
npm install

# 6. Créer .env.local
nano .env.local
# Ajouter vos variables

# 7. Build
npm run build

# 8. Copier vers nginx
sudo cp -r dist/* /var/www/html/

# 9. Configurer nginx
sudo nano /etc/nginx/sites-available/default
```

Configuration nginx :
```nginx
server {
    listen 80;
    server_name votre-domaine.com;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

```bash
# 10. Redémarrer nginx
sudo systemctl restart nginx

# 11. (Optionnel) Configurer SSL avec Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d votre-domaine.com
```

## ✅ Checklist post-déploiement

- [ ] Le site est accessible
- [ ] Les images se chargent correctement
- [ ] L'authentification fonctionne
- [ ] Le mode sombre/clair fonctionne
- [ ] La recherche fonctionne
- [ ] Les guides peuvent être créés
- [ ] Les collections fonctionnent
- [ ] Le site est responsive (mobile/tablette/desktop)
- [ ] Les erreurs sont loggées (Sentry, LogRocket, etc.)
- [ ] Analytics configuré (Google Analytics, Plausible, etc.)
- [ ] SEO optimisé (meta tags, sitemap, robots.txt)
- [ ] SSL/HTTPS actif
- [ ] Domaine personnalisé configuré

## 🔧 Monitoring et maintenance

### Outils recommandés

- **Analytics:** [Google Analytics](https://analytics.google.com), [Plausible](https://plausible.io)
- **Erreurs:** [Sentry](https://sentry.io)
- **Performance:** [Lighthouse](https://developers.google.com/web/tools/lighthouse)
- **Uptime:** [UptimeRobot](https://uptimerobot.com)

### Mises à jour

```bash
# Localement
git pull origin main
npm install
npm run build

# Déployer selon votre méthode
vercel --prod
# ou
netlify deploy --prod
# ou
git push # (GitHub Pages auto-deploy)
```

---

**Bon déploiement ! 🚀**
