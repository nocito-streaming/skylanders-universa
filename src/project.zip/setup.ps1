# Script de configuration du projet Skylanders Universe (Windows)
# Usage: .\setup.ps1

Write-Host "🎮 Configuration de Skylanders Universe..." -ForegroundColor Cyan
Write-Host ""

# Vérifier Node.js
try {
    $nodeVersion = node -v
    Write-Host "✅ Node.js $nodeVersion détecté" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js n'est pas installé. Installez-le depuis https://nodejs.org/" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Vérifier npm
try {
    $npmVersion = npm -v
    Write-Host "✅ npm $npmVersion détecté" -ForegroundColor Green
} catch {
    Write-Host "❌ npm n'est pas installé" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Installer les dépendances
Write-Host "📦 Installation des dépendances..." -ForegroundColor Yellow
npm install

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Dépendances installées avec succès" -ForegroundColor Green
} else {
    Write-Host "❌ Erreur lors de l'installation des dépendances" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Créer .env.local si n'existe pas
if (!(Test-Path .env.local)) {
    Write-Host "📝 Création du fichier .env.local..." -ForegroundColor Yellow
    Copy-Item .env.example .env.local
    Write-Host "⚠️  N'oubliez pas de remplir .env.local avec vos clés Supabase !" -ForegroundColor Yellow
} else {
    Write-Host "✅ .env.local existe déjà" -ForegroundColor Green
}

Write-Host ""
Write-Host "🎉 Configuration terminée !" -ForegroundColor Green
Write-Host ""
Write-Host "Prochaines étapes :" -ForegroundColor Cyan
Write-Host "1. Éditez .env.local avec vos clés Supabase"
Write-Host "2. Lancez le serveur de dev : npm run dev"
Write-Host "3. Ouvrez http://localhost:3000"
Write-Host ""
Write-Host "📚 Documentation complète : README.md" -ForegroundColor Cyan
Write-Host "🚀 Guide rapide : QUICK_START.md" -ForegroundColor Cyan
Write-Host ""
