#!/bin/bash

echo "🔧 Correction des imports avec versions spécifiques..."

# Fonction pour corriger les imports dans un fichier
fix_file() {
    local file="$1"
    echo "  Correction de: $file"
    
    # Remplacer tous les imports avec @version par imports normaux
    sed -i 's/@radix-ui\/react-slot@[0-9.]*/@radix-ui\/react-slot/g' "$file"
    sed -i 's/class-variance-authority@[0-9..]*/class-variance-authority/g' "$file"
    sed -i 's/lucide-react@[0-9..]*/lucide-react/g' "$file"
    sed -i 's/@radix-ui\/react-label@[0-9.]*/@radix-ui\/react-label/g' "$file"
}

# Parcourir tous les fichiers .tsx dans components/ui/
find components/ui -name "*.tsx" -type f | while read file; do
    fix_file "$file"
done

echo "✅ Correction terminée!"
echo "Lancez maintenant: npm run dev"
