# 🚀 Guide de démarrage rapide

Ce guide vous aidera à lancer le projet Skylanders Universe en quelques minutes.

## ⚡ Installation rapide

### 1. Cloner le projet
```bash
git clone https://github.com/votre-username/skylanders-universe.git
cd skylanders-universe
```

### 2. Installer les dépendances
```bash
npm install
```

### 3. Configuration minimale

Créez un fichier `.env.local` :
```env
VITE_SUPABASE_URL=https://demo.supabase.co
VITE_SUPABASE_ANON_KEY=demo-key
```

> **Note:** Pour une utilisation en production, créez votre propre projet Supabase gratuit sur [supabase.com](https://supabase.com)

### 4. Lancer le projet
```bash
npm run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000) dans votre navigateur.

## 📱 Fonctionnalités disponibles sans Supabase

Le projet fonctionne partiellement sans configuration Supabase :
- ✅ Navigation dans l'application
- ✅ Consultation de la base de données Skylanders (350+ personnages)
- ✅ Filtrage et recherche
- ✅ Consultation des jeux
- ✅ Mode sombre/clair
- ✅ Collections locales (stockées dans le navigateur)
- ❌ Authentification (nécessite Supabase)
- ❌ Guides communautaires (nécessite Supabase)
- ❌ Profil utilisateur (nécessite Supabase)

## 🔧 Configuration complète Supabase

### Étape 1 : Créer un projet Supabase

1. Allez sur [supabase.com](https://supabase.com)
2. Créez un compte (gratuit)
3. Cliquez sur "New Project"
4. Remplissez les informations :
   - **Name:** skylanders-universe
   - **Database Password:** choisissez un mot de passe fort
   - **Region:** choisissez la plus proche
5. Cliquez sur "Create new project"

### Étape 2 : Récupérer les identifiants

1. Dans votre projet Supabase, allez dans **Settings** (⚙️)
2. Cliquez sur **API**
3. Copiez les valeurs suivantes :
   - **Project URL** → `VITE_SUPABASE_URL`
   - **anon public** → `VITE_SUPABASE_ANON_KEY`

### Étape 3 : Mettre à jour .env.local

```env
VITE_SUPABASE_URL=https://votre-projet-id.supabase.co
VITE_SUPABASE_ANON_KEY=votre-cle-anon-tres-longue
VITE_SUPABASE_PROJECT_ID=votre-projet-id
```

### Étape 4 : Configurer l'authentification Google (optionnel)

1. Dans Supabase, allez dans **Authentication** > **Providers**
2. Activez **Google**
3. Pour obtenir les identifiants OAuth :
   - Allez sur [Google Cloud Console](https://console.cloud.google.com)
   - Créez un nouveau projet
   - Activez l'API Google+
   - Créez des identifiants OAuth 2.0
   - Ajoutez `https://votre-projet.supabase.co/auth/v1/callback` dans les URI de redirection autorisées
   - Copiez Client ID et Client Secret dans Supabase

### Étape 5 : Relancer le serveur

```bash
npm run dev
```

Vous pouvez maintenant :
- ✅ Créer un compte
- ✅ Se connecter avec Google
- ✅ Créer des guides
- ✅ Sauvegarder vos collections en ligne

## 🌐 Déploiement rapide sur Vercel

### Option 1 : Déploiement en 1 clic

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/votre-username/skylanders-universe)

### Option 2 : Ligne de commande

```bash
# Installer Vercel CLI
npm i -g vercel

# Se connecter
vercel login

# Déployer
vercel

# Configurer les variables d'environnement
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY

# Déployer en production
vercel --prod
```

## 📝 Commandes utiles

```bash
# Développement
npm run dev          # Lancer le serveur de dev (port 3000)

# Build
npm run build        # Compiler pour la production
npm run preview      # Prévisualiser le build de production

# Qualité du code
npm run lint         # Vérifier le code avec ESLint
npm run lint:fix     # Corriger automatiquement les erreurs
```

## 🆘 Problèmes courants

### Le serveur ne démarre pas

**Erreur:** `EADDRINUSE: address already in use`
```bash
# Un autre processus utilise le port 3000
# Solution 1 : Changer le port dans vite.config.ts
# Solution 2 : Tuer le processus
lsof -ti:3000 | xargs kill
```

### Erreurs de dépendances

```bash
# Supprimer node_modules et réinstaller
rm -rf node_modules package-lock.json
npm install
```

### Variables d'environnement non détectées

- Assurez-vous que le fichier s'appelle `.env.local` (pas `.env`)
- Redémarrez le serveur après modification
- Les variables doivent commencer par `VITE_`

### Erreur Supabase

**Erreur:** `Invalid API key`
- Vérifiez que vous avez copié la clé `anon public` (pas la clé `service_role`)
- Vérifiez qu'il n'y a pas d'espaces avant/après dans le .env.local

## 📚 Ressources supplémentaires

- [Documentation complète](./README.md)
- [Guide des composants](./COMPONENTS_GUIDE.md)
- [Architecture du code](./ORGANISATION_CODE.md)
- [Guide de contribution](./CONTRIBUTING.md)

## 💬 Besoin d'aide ?

- 🐛 [Ouvrir une issue](https://github.com/votre-username/skylanders-universe/issues)
- 💬 [Discussions](https://github.com/votre-username/skylanders-universe/discussions)
- 📧 Email : support@skylanders-universe.com

---

**Bon développement ! 🎮**
